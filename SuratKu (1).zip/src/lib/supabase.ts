import { createClient } from '@supabase/supabase-js';
import { MailEntry } from '../types';

// Replace these with your actual Supabase project credentials
const supabaseUrl = 'YOUR_SUPABASE_PROJECT_URL';
const supabaseAnonKey = 'YOUR_SUPABASE_ANON_KEY';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type { MailEntry };

export async function fetchMails() {
  try {
    const { data, error } = await supabase
      .from('mails')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data as MailEntry[];
  } catch (error) {
    console.error('Error fetching mails:', error);
    throw error;
  }
}

export async function createMail(mail: Omit<MailEntry, 'id'>) {
  try {
    const { data, error } = await supabase
      .from('mails')
      .insert([mail])
      .select()
      .single();

    if (error) throw error;
    return data as MailEntry;
  } catch (error) {
    console.error('Error creating mail:', error);
    throw error;
  }
}

export async function deleteMail(id: string) {
  try {
    const { error } = await supabase
      .from('mails')
      .delete()
      .eq('id', id);

    if (error) throw error;
  } catch (error) {
    console.error('Error deleting mail:', error);
    throw error;
  }
}
