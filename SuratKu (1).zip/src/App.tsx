import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { LoginPage } from './components/LoginPage';
import Dashboard from './components/Dashboard';
import { AuthState } from './types';


function App() {
  const [auth, setAuth] = useState<AuthState>(() => {
    const saved = localStorage.getItem('auth');
    return saved ? JSON.parse(saved) : { isAuthenticated: false, username: null, role: null };
  });

  

  useEffect(() => {
    localStorage.setItem('auth', JSON.stringify(auth));
  }, [auth]);

  const handleLogin = (username: string, role: 'admin' | 'guest') => {
    setAuth({ isAuthenticated: true, username, role });
  };

  const handleLogout = () => {
    setAuth({ isAuthenticated: false, username: null, role: null });
  };

  return (
    <Router>
      <Routes>
        <Route
          path="/"
          element={
            auth.isAuthenticated ? (
              <Navigate to="/dashboard" replace />
            ) : (
              <LoginPage onLogin={handleLogin} />
            )
          }
        />
        <Route
          path="/dashboard"
          element={
            auth.isAuthenticated ? (
              <Dashboard onLogout={handleLogout} username={auth.username} role={auth.role} />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />
      </Routes>
    </Router>
  );
}

export default App;
