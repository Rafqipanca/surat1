export interface MailEntry {
  id: string;
  sequenceNumber: string;
  mailCode: string;
  mailNumber: string;
  date: string;
  sender: string;
  recipient: string;
  subject: string;
  content: string;
  category: 'masuk' | 'keluar';
}

export interface AuthState {
  isAuthenticated: boolean;
  username: string | null;
  role: 'admin' | 'guest' | null;
}
