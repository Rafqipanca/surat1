export interface MailCode {
  code: string;
  description: string;
}

export const incomingMailCodes: MailCode[] = [
  { code: "SM/01", description: "Surat Dinas" },
  { code: "SM/02", description: "Surat Undangan" },
  { code: "SM/03", description: "Surat Permohonan" },
  { code: "SM/04", description: "Surat Pemberitahuan" },
  { code: "SM/05", description: "Surat Keputusan" },
  { code: "SM/06", description: "Nota Dinas" },
  { code: "SM/07", description: "Memorandum" },
  { code: "SM/08", description: "Surat Edaran" },
  { code: "SM/09", description: "Laporan" },
  { code: "SM/10", description: "Lain-lain" },
];

export const outgoingMailCodes: MailCode[] = [
  { code: "SK/01", description: "Surat Dinas" },
  { code: "SK/02", description: "Surat Undangan" },
  { code: "SK/03", description: "Surat Permohonan" },
  { code: "SK/04", description: "Surat Pemberitahuan" },
  { code: "SK/05", description: "Surat Keputusan" },
  { code: "SK/06", description: "Nota Dinas" },
  { code: "SK/07", description: "Memorandum" },
  { code: "SK/08", description: "Surat Edaran" },
  { code: "SK/09", description: "Laporan" },
  { code: "SK/10", description: "Lain-lain" },
];
