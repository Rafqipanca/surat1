import { Mail } from 'lucide-react';
import { MailEntry } from '../types';
import { incomingMailCodes, outgoingMailCodes } from '../data/mailLookup';

interface MailCardProps {
  mail: MailEntry;
  onDelete: (id: string) => void;
  onView: (mail: MailEntry) => void;
  showDelete: boolean;
}

export function MailCard({ mail, onDelete, onView, showDelete }: MailCardProps) {
  const getMailCodeDescription = (code: string, category: 'masuk' | 'keluar'): string => {
    const codes = category === 'masuk' ? incomingMailCodes : outgoingMailCodes;
    const found = codes.find(c => c.code === code);
    return found ? found.description : code;
  };

  return (
    <div className="bg-white rounded-xl p-4 shadow-lg border border-gray-200 hover:bg-gray-50 transition-all">
      <div className="flex gap-4">
        {/* Left side - Icon */}
        <div className="flex-shrink-0">
          <Mail 
            className={`w-[24px] h-[24px] ${
              mail.category === 'masuk' ? 'text-green-600' : 'text-red-600'
            }`}
          />
        </div>

        {/* Middle - Content */}
        <div className="flex-grow grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
          <div className="col-span-2">
            <h3 className="font-semibold text-gray-900 text-sm">Perihal: {mail.subject}</h3>
            <p className="text-sm text-gray-600">Tanggal: {mail.date}</p>
          </div>

          <div>
            <span className="text-gray-600 text-sm">No. Urut:</span>
            <p className="text-sm text-gray-900">{mail.sequenceNumber}</p>
          </div>

          <div>
            <span className="text-gray-600 text-sm">Nomor Surat:</span>
            <p className="text-sm text-gray-900">{mail.mailNumber}</p>
          </div>

          <div>
            <span className="text-gray-600 text-sm">Kode Surat:</span>
            <p className="text-sm text-gray-900">
              {mail.mailCode} - {getMailCodeDescription(mail.mailCode, mail.category)}
            </p>
          </div>

          <div>
            <span className="text-gray-600 text-sm">Pengirim:</span>
            <p className="text-sm text-gray-900">{mail.sender}</p>
          </div>

          <div>
            <span className="text-gray-600 text-sm">Penerima:</span>
            <p className="text-sm text-gray-900">{mail.recipient}</p>
          </div>
        </div>

        {/* Right side - Buttons */}
        <div className="flex-shrink-0 flex flex-col gap-2">
          <button
            onClick={() => onView(mail)}
            className="px-4 py-1 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap"
          >
            Lihat
          </button>
          {showDelete && (
            <button
              onClick={() => onDelete(mail.id)}
              className="px-4 py-1 text-sm bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors whitespace-nowrap"
            >
              Hapus
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
