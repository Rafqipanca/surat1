import { FormEvent, useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { MailEntry } from '../types';
import { incomingMailCodes, outgoingMailCodes } from '../data/mailLookup';

interface NewMailFormProps {
  onSubmit: (mail: Omit<MailEntry, 'id'>) => void;
  onClose: () => void;
  incomingMailsCount: number;
  outgoingMailsCount: number;
}

export function NewMailForm({ onSubmit, onClose, incomingMailsCount, outgoingMailsCount }: NewMailFormProps) {
  const [category, setCategory] = useState<'masuk' | 'keluar'>('masuk');
  const [formData, setFormData] = useState({
    sequenceNumber: '',
    mailCode: '',
    mailNumber: '',
    subject: '',
    sender: '',
    recipient: '',
    content: '',
    date: new Date().toISOString().split('T')[0],
  });

  useEffect(() => {
    const count = category === 'masuk' ? incomingMailsCount : outgoingMailsCount;
    const newSequenceNumber = (count + 1).toString().padStart(3, '0');
    setFormData(prev => ({
      ...prev,
      sequenceNumber: newSequenceNumber,
      mailCode: '',
    }));
  }, [category, incomingMailsCount, outgoingMailsCount]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      category,
    });
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4">
      <div className="bg-gray-800/90 backdrop-blur-lg rounded-xl p-6 w-full max-w-3xl text-gray-200">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Surat Baru</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-200">
            <X className="w-5 h-5" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300">Nomor Urut</label>
              <input
                type="text"
                disabled
                className="mt-1 block w-full rounded-lg border-gray-700 bg-gray-700 p-2 text-gray-300"
                value={formData.sequenceNumber}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300">Kategori</label>
              <select
                className="mt-1 block w-full rounded-lg border-gray-700 bg-gray-800 p-2 text-gray-200"
                value={category}
                onChange={(e) => setCategory(e.target.value as 'masuk' | 'keluar')}
              >
                <option value="masuk">Surat Masuk</option>
                <option value="keluar">Surat Keluar</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300">Kode Surat</label>
              <select
                required
                className="mt-1 block w-full rounded-lg border-gray-700 bg-gray-800 p-2 text-gray-200"
                value={formData.mailCode}
                onChange={(e) => setFormData({ ...formData, mailCode: e.target.value })}
              >
                <option value="">Pilih Kode Surat</option>
                {(category === 'masuk' ? incomingMailCodes : outgoingMailCodes).map((code) => (
                  <option key={code.code} value={code.code}>
                    {code.code} - {code.description}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300">Nomor Surat</label>
              <input
                type="text"
                required
                className="mt-1 block w-full rounded-lg border-gray-700 bg-gray-800 p-2 text-gray-200"
                value={formData.mailNumber}
                onChange={(e) => setFormData({ ...formData, mailNumber: e.target.value })}
                placeholder="Contoh: 001/ABC/2024"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300">Tanggal</label>
              <input
                type="date"
                required
                className="mt-1 block w-full rounded-lg border-gray-700 bg-gray-800 p-2 text-gray-200"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300">Pengirim</label>
              <input
                type="text"
                required
                className="mt-1 block w-full rounded-lg border-gray-700 bg-gray-800 p-2 text-gray-200"
                value={formData.sender}
                onChange={(e) => setFormData({ ...formData, sender: e.target.value })}
              />
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-300">Penerima</label>
              <input
                type="text"
                required
                className="mt-1 block w-full rounded-lg border-gray-700 bg-gray-800 p-2 text-gray-200"
                value={formData.recipient}
                onChange={(e) => setFormData({ ...formData, recipient: e.target.value })}
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300">Perihal</label>
            <input
              type="text"
              required
              className="mt-1 block w-full rounded-lg border-gray-700 bg-gray-800 p-2 text-gray-200"
              value={formData.subject}
              onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300">Isi Surat</label>
            <textarea
              required
              className="mt-1 block w-full rounded-lg border-gray-700 bg-gray-800 p-2 text-gray-200"
              rows={4}
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
            />
          </div>
          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-gray-700 text-white rounded-lg py-2 hover:bg-gray-600 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 bg-blue-600 text-white rounded-lg py-2 hover:bg-blue-700 transition-colors"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
