import { useState, useEffect } from 'react';
import { Plus, Search, LogOut, Printer } from 'lucide-react';
import { MailEntry } from '../types';
import { MailCard } from './MailCard';
import { NewMailForm } from './NewMailForm';
import { fetchMails, createMail, deleteMail } from '../lib/supabase';

interface DashboardProps {
  onLogout: () => void;
  username: string | null;
  role: 'admin' | 'guest' | null;
}

function Dashboard({ onLogout, username, role }: DashboardProps) {
  const [mails, setMails] = useState<MailEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showNewMailForm, setShowNewMailForm] = useState(false);
  const [selectedMail, setSelectedMail] = useState<MailEntry | null>(null);
  const [filter, setFilter] = useState<'semua' | 'masuk' | 'keluar'>('semua');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadMails();
  }, []);

  const loadMails = async () => {
    try {
      setLoading(true);
      const data = await fetchMails();
      setMails(data);
      setError(null);
    } catch (err) {
      setError('Failed to load mails. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const handleNewMail = async (mailData: Omit<MailEntry, 'id'>) => {
    try {
      const newMail = await createMail(mailData);
      setMails([newMail, ...mails]);
      setShowNewMailForm(false);
    } catch (err) {
      setError('Failed to create mail. Please try again.');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteMail(id);
      setMails(mails.filter(mail => mail.id !== id));
    } catch (err) {
      setError('Failed to delete mail. Please try again.');
    }
  };

  const handlePrint = (category: 'masuk' | 'keluar') => {
    const mailsToPrint = mails.filter(mail => mail.category === category);
    const title = category === 'masuk' ? 'Surat Masuk' : 'Surat Keluar';
    
    const printContent = `
      <html>
        <head>
          <title>${title}</title>
          <style>
            body { font-family: Arial, sans-serif; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            h1 { text-align: center; }
          </style>
        </head>
        <body>
          <h1>${title}</h1>
          <table>
            <thead>
              <tr>
                <th>No. Urut</th>
                <th>Tanggal</th>
                <th>No. Surat</th>
                <th>Pengirim</th>
                <th>Penerima</th>
                <th>Perihal</th>
              </tr>
            </thead>
            <tbody>
              ${mailsToPrint.map(mail => `
                <tr>
                  <td>${mail.sequenceNumber}</td>
                  <td>${mail.date}</td>
                  <td>${mail.mailNumber}</td>
                  <td>${mail.sender}</td>
                  <td>${mail.recipient}</td>
                  <td>${mail.subject}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const filteredMails = mails.filter(mail => {
    if (filter !== 'semua' && mail.category !== filter) return false;
    
    if (searchQuery) {
      const searchLower = searchQuery.toLowerCase();
      return (
        mail.subject.toLowerCase().includes(searchLower) ||
        mail.sender.toLowerCase().includes(searchLower) ||
        mail.recipient.toLowerCase().includes(searchLower) ||
        mail.mailNumber.toLowerCase().includes(searchLower) ||
        mail.content.toLowerCase().includes(searchLower)
      );
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800">
      <div className="max-w-2xl mx-auto p-4">
        <header className="flex justify-between items-center mb-8 pt-8">
          <div className="text-left">
            <h1 className="text-3xl font-bold text-gray-100 mb-2">SuratKu</h1>
            <p className="text-gray-400">SLB Negeri Kotagajah</p>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-gray-300">Welcome, {username}</span>
            <button
              onClick={onLogout}
              className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
        </header>

        {error && (
          <div className="bg-red-500/10 border border-red-500 text-red-200 px-4 py-3 rounded-lg mb-4">
            {error}
          </div>
        )}

        <div className="space-y-4 mb-6">
          <div className="flex flex-wrap gap-4">
            <select
              className="flex-1 min-w-[200px] rounded-lg px-3 py-2 bg-gray-800/50 backdrop-blur-sm border border-gray-700 text-gray-200"
              value={filter}
              onChange={(e) => setFilter(e.target.value as 'semua' | 'masuk' | 'keluar')}
            >
              <option value="semua">Semua Surat</option>
              <option value="masuk">Surat Masuk</option>
              <option value="keluar">Surat Keluar</option>
            </select>

            <div className="flex gap-2">
              <button
                onClick={() => handlePrint('masuk')}
                className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-gray-200 rounded-lg flex items-center gap-2 transition-colors"
              >
                <Printer className="w-4 h-4" />
                Print Surat Masuk
              </button>
              <button
                onClick={() => handlePrint('keluar')}
                className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-gray-200 rounded-lg flex items-center gap-2 transition-colors"
              >
                <Printer className="w-4 h-4" />
                Print Surat Keluar
              </button>
              {role === 'admin' && (
                <button
                  onClick={() => setShowNewMailForm(true)}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  Surat Baru
                </button>
              )}
            </div>
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Cari surat berdasarkan subjek, pengirim, penerima, atau nomor surat..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-lg bg-gray-800/50 backdrop-blur-sm border border-gray-700 text-gray-200 placeholder-gray-500"
            />
          </div>
        </div>

        <div className="space-y-4">
          {loading ? (
            <div className="text-center py-8 text-gray-400">Loading...</div>
          ) : filteredMails.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              {searchQuery 
                ? "Tidak ada surat yang sesuai dengan pencarian"
                : "Tidak ada surat untuk ditampilkan"}
            </div>
          ) : (
            filteredMails.map((mail) => (
              <MailCard
                key={mail.id}
                mail={mail}
                onDelete={() => handleDelete(mail.id)}
                onView={setSelectedMail}
                showDelete={role === 'admin'}
              />
            ))
          )}
        </div>

        {showNewMailForm && (
          <NewMailForm
            onSubmit={handleNewMail}
            onClose={() => setShowNewMailForm(false)}
            incomingMailsCount={mails.filter(m => m.category === 'masuk').length}
            outgoingMailsCount={mails.filter(m => m.category === 'keluar').length}
          />
        )}

        {selectedMail && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4">
            <div className="bg-gray-800/90 backdrop-blur-lg rounded-xl p-6 w-full max-w-md text-gray-200">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">Perihal: {selectedMail.subject}</h2>
                <button
                  onClick={() => setSelectedMail(null)}
                  className="text-gray-400 hover:text-gray-200"
                >
                  ×
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-400">Dari: {selectedMail.sender}</p>
                  <p className="text-sm text-gray-400">Kepada: {selectedMail.recipient}</p>
                  <p className="text-sm text-gray-400">Tanggal: {selectedMail.date}</p>
                </div>
                <p className="text-gray-300 whitespace-pre-wrap">{selectedMail.content}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default Dashboard;
